*** Setting ***
Variables   Var.py

*** Variables ***
${myTest}   ${a}
${NAME} 	${chrome}

${Browser}   https://www.google.com/
${EMAILID} =  {email}